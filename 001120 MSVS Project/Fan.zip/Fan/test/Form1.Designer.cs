﻿namespace test
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.loySerialPortUc1 = new LoySerialPortUserControl.LoySerialPortUc();
            this.textBoxRX = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxTx = new System.Windows.Forms.TextBox();
            this.buttonSend = new System.Windows.Forms.Button();
            this.buttonFan0 = new System.Windows.Forms.Button();
            this.buttonFan3 = new System.Windows.Forms.Button();
            this.buttonFan2 = new System.Windows.Forms.Button();
            this.buttonFan1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // loySerialPortUc1
            // 
            this.loySerialPortUc1.Location = new System.Drawing.Point(32, 355);
            this.loySerialPortUc1.Name = "loySerialPortUc1";
            this.loySerialPortUc1.RxMode = "text";
            this.loySerialPortUc1.Size = new System.Drawing.Size(292, 37);
            this.loySerialPortUc1.TabIndex = 0;
            // 
            // textBoxRX
            // 
            this.textBoxRX.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxRX.Location = new System.Drawing.Point(32, 38);
            this.textBoxRX.Multiline = true;
            this.textBoxRX.Name = "textBoxRX";
            this.textBoxRX.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxRX.Size = new System.Drawing.Size(445, 34);
            this.textBoxRX.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Message from Arduino";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Message to Arduino";
            // 
            // textBoxTx
            // 
            this.textBoxTx.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTx.Location = new System.Drawing.Point(32, 107);
            this.textBoxTx.Multiline = true;
            this.textBoxTx.Name = "textBoxTx";
            this.textBoxTx.Size = new System.Drawing.Size(348, 31);
            this.textBoxTx.TabIndex = 3;
            // 
            // buttonSend
            // 
            this.buttonSend.Location = new System.Drawing.Point(402, 107);
            this.buttonSend.Name = "buttonSend";
            this.buttonSend.Size = new System.Drawing.Size(75, 29);
            this.buttonSend.TabIndex = 5;
            this.buttonSend.Text = "Send";
            this.buttonSend.UseVisualStyleBackColor = true;
            this.buttonSend.Click += new System.EventHandler(this.buttonSend_Click);
            // 
            // buttonFan0
            // 
            this.buttonFan0.BackgroundImage = global::test.Resource1.fanStop;
            this.buttonFan0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonFan0.Location = new System.Drawing.Point(29, 180);
            this.buttonFan0.Name = "buttonFan0";
            this.buttonFan0.Size = new System.Drawing.Size(67, 41);
            this.buttonFan0.TabIndex = 9;
            this.buttonFan0.UseVisualStyleBackColor = true;
            this.buttonFan0.Click += new System.EventHandler(this.buttonFan0_Click);
            // 
            // buttonFan3
            // 
            this.buttonFan3.BackgroundImage = global::test.Resource1.fan;
            this.buttonFan3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonFan3.Location = new System.Drawing.Point(336, 170);
            this.buttonFan3.Name = "buttonFan3";
            this.buttonFan3.Size = new System.Drawing.Size(141, 66);
            this.buttonFan3.TabIndex = 8;
            this.buttonFan3.UseVisualStyleBackColor = true;
            this.buttonFan3.Click += new System.EventHandler(this.buttonFan3_Click);
            // 
            // buttonFan2
            // 
            this.buttonFan2.BackgroundImage = global::test.Resource1.fan;
            this.buttonFan2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonFan2.Location = new System.Drawing.Point(204, 174);
            this.buttonFan2.Name = "buttonFan2";
            this.buttonFan2.Size = new System.Drawing.Size(105, 54);
            this.buttonFan2.TabIndex = 7;
            this.buttonFan2.UseVisualStyleBackColor = true;
            this.buttonFan2.Click += new System.EventHandler(this.buttonFan2_Click);
            // 
            // buttonFan1
            // 
            this.buttonFan1.BackgroundImage = global::test.Resource1.fan;
            this.buttonFan1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonFan1.Location = new System.Drawing.Point(114, 181);
            this.buttonFan1.Name = "buttonFan1";
            this.buttonFan1.Size = new System.Drawing.Size(67, 41);
            this.buttonFan1.TabIndex = 6;
            this.buttonFan1.UseVisualStyleBackColor = true;
            this.buttonFan1.Click += new System.EventHandler(this.buttonFan1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(520, 414);
            this.Controls.Add(this.buttonFan0);
            this.Controls.Add(this.buttonFan3);
            this.Controls.Add(this.buttonFan2);
            this.Controls.Add(this.buttonFan1);
            this.Controls.Add(this.buttonSend);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxTx);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxRX);
            this.Controls.Add(this.loySerialPortUc1);
            this.Name = "Form1";
            this.Text = "Fan Control";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private LoySerialPortUserControl.LoySerialPortUc loySerialPortUc1;
        private System.Windows.Forms.TextBox textBoxRX;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxTx;
        private System.Windows.Forms.Button buttonSend;
        private System.Windows.Forms.Button buttonFan1;
        private System.Windows.Forms.Button buttonFan2;
        private System.Windows.Forms.Button buttonFan3;
        private System.Windows.Forms.Button buttonFan0;
    }
}

