﻿using System;
using System.Windows.Forms;

namespace test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            loySerialPortUc1.OnDataReceived 
                += LoySerialPortUc1_OnDataReceived;
        }

        private void LoySerialPortUc1_OnDataReceived(string recieveString)
        {
            textBoxRX.Invoke(new Action(() =>
            { textBoxRX.AppendText(recieveString); }));
        }

        private void buttonSend_Click(object sender, EventArgs e)
        {
            loySerialPortUc1.Write(textBoxTx.Text);
        }

        private void buttonFan1_Click(object sender, EventArgs e)
        {
            loySerialPortUc1.Write("40");
        }

        private void buttonFan2_Click(object sender, EventArgs e)
        {
            loySerialPortUc1.Write("120");
        }

        private void buttonFan3_Click(object sender, EventArgs e)
        {
            loySerialPortUc1.Write("255");
        }

        private void buttonFan0_Click(object sender, EventArgs e)
        {
            loySerialPortUc1.Write("0");
        }
    }
}

