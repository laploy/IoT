﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            loySerialPortUc1.OnDataReceived += LoySerialPortUc1_OnDataReceived;
        }
        private void LoySerialPortUc1_OnDataReceived(string recieveString)
        {
            textBoxRX.Invoke(new Action(() =>
            { textBoxRX.Text = recieveString; }));
            int d = Convert.ToInt32(recieveString);
            if(d > 0)
            pictureBox1.Invoke(new Action(() =>
            { pictureBox1.Left = d*10; }));
        }
    }
}
