﻿namespace test
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.loySerialPortUc1 = new LoySerialPortUserControl.LoySerialPortUc();
            this.textBoxRX = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // loySerialPortUc1
            // 
            this.loySerialPortUc1.Location = new System.Drawing.Point(102, 632);
            this.loySerialPortUc1.Name = "loySerialPortUc1";
            this.loySerialPortUc1.RxMode = "text";
            this.loySerialPortUc1.Size = new System.Drawing.Size(292, 37);
            this.loySerialPortUc1.TabIndex = 0;
            // 
            // textBoxRX
            // 
            this.textBoxRX.Location = new System.Drawing.Point(32, 38);
            this.textBoxRX.Multiline = true;
            this.textBoxRX.Name = "textBoxRX";
            this.textBoxRX.Size = new System.Drawing.Size(316, 79);
            this.textBoxRX.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Message from Arduino";
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::test.Resource1.floorPlan;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(32, 123);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(592, 485);
            this.panel1.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(54, 14);
            this.button1.Margin = new System.Windows.Forms.Padding(0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(107, 21);
            this.button1.TabIndex = 4;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(673, 678);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxRX);
            this.Controls.Add(this.loySerialPortUc1);
            this.Name = "Form1";
            this.Text = "Light Sensor";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private LoySerialPortUserControl.LoySerialPortUc loySerialPortUc1;
        private System.Windows.Forms.TextBox textBoxRX;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
    }
}

