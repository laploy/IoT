﻿/// <remarks>
/// Laploy V.Angkul
/// laploy@gmail.com
/// July ,2017
/// </remarks>

using System;
using System.Windows.Forms;

namespace test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            loySerialPortUc1.OnDataReceived += LoySerialPortUc1_OnDataReceived;
        }

        private void LoySerialPortUc1_OnDataReceived(string recieveString)
        {
            textBox1.Invoke(new Action(() =>
            { textBox1.AppendText(recieveString); }));
        }
    }
}
