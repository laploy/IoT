﻿/// <remarks>
/// Laploy V.Angkul
/// laploy@gmail.com
/// July ,2017
/// </remarks>
/// 
using System;
using System.Drawing;
using System.Windows.Forms;

namespace LoySerialPortUserControl
{
    public delegate void LoyDataReceived(string recieveString);
    public partial class LoySerialPortUc : UserControl
    {
        public string RxMode
        {
            get { return rxMode; }
            set { rxMode = value; }
        }
        public bool PortOpen
        {
            get
            {
                return portOpen;
            }
        }
        public event LoyDataReceived OnDataReceived;
        private CommRS232 myComPort;
        private string rxMode = "text";
        private bool flipFlopAck = false;
        private string myPortName = "COM1";
        private bool portOpen = false;

        public LoySerialPortUc()
        {
            InitializeComponent();
            buttonAck.Enabled = false;
            enumComport();
        }
        private void enumComport()
        {
            string[] serialPortNames1 = System.IO.Ports.SerialPort.GetPortNames();
            comboBoxPort.DataSource = serialPortNames1;
        }
        private void buttonOpen_Click(object sender, EventArgs e)
        {
            if (portOpen)
            {
                myComPort.Close();
                buttonOpen.Text = "Open";
                comboBoxPort.Enabled = true;
            }
            else
            {
                myComPort = new CommRS232(myPortName);
                myComPort.OnDataReceived += MyComPort_OnDataReceived;
                myComPort.InitPort();
                myComPort.Open();
                buttonOpen.Text = "Close";
                comboBoxPort.Enabled = false;
            }
            portOpen = !portOpen;
        }

        private void MyComPort_OnDataReceived(string recieveString)
        {
            UpdateLed();
            try
            {
                OnDataReceived(recieveString);
            }
            catch (Exception)
            {
                Console.WriteLine("Error: OnDataRecived Event handler not found");
            }
        }

        void myComPort_OnDataReceivedAsc(string recieveString)
        {
            UpdateLed();
            try
            {
                OnDataReceived(recieveString);
            }
            catch (Exception)
            {
                Console.WriteLine("Error: OnDataRecived Event handler not found");
            }
            
        }
        private void UpdateLed()
        {
            if (flipFlopAck)
                buttonAck.BackColor = Color.GreenYellow;
            else
                buttonAck.BackColor = Color.DarkGreen;
            flipFlopAck = !flipFlopAck;
        }
        public void Write(string s)
        {
            if (myPortName == null) return;
            UpdateLed();
            myComPort.Write(s);
        }
        private void comboBoxDnp3_SelectedIndexChanged(object sender, EventArgs e)
        {
            myPortName = comboBoxPort.Text;
        }
    }
}
