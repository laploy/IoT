﻿namespace LoySerialPortUserControl
{
    partial class LoySerialPortUc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonOpen = new System.Windows.Forms.Button();
            this.comboBoxPort = new System.Windows.Forms.ComboBox();
            this.buttonAck = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonOpen
            // 
            this.buttonOpen.Location = new System.Drawing.Point(221, 2);
            this.buttonOpen.Margin = new System.Windows.Forms.Padding(4);
            this.buttonOpen.Name = "buttonOpen";
            this.buttonOpen.Size = new System.Drawing.Size(66, 29);
            this.buttonOpen.TabIndex = 30;
            this.buttonOpen.Text = "Open";
            this.buttonOpen.UseVisualStyleBackColor = true;
            this.buttonOpen.Click += new System.EventHandler(this.buttonOpen_Click);
            // 
            // comboBoxDnp3
            // 
            this.comboBoxPort.FormattingEnabled = true;
            this.comboBoxPort.Location = new System.Drawing.Point(114, 4);
            this.comboBoxPort.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxPort.Name = "comboBoxDnp3";
            this.comboBoxPort.Size = new System.Drawing.Size(99, 24);
            this.comboBoxPort.TabIndex = 29;
            this.comboBoxPort.SelectedIndexChanged += new System.EventHandler(this.comboBoxDnp3_SelectedIndexChanged);
            // 
            // buttonAck
            // 
            this.buttonAck.Location = new System.Drawing.Point(7, 8);
            this.buttonAck.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAck.Name = "buttonAck";
            this.buttonAck.Size = new System.Drawing.Size(17, 17);
            this.buttonAck.TabIndex = 32;
            this.buttonAck.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 8);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 17);
            this.label1.TabIndex = 34;
            this.label1.Text = "Serial Port";
            // 
            // LoySerialPortUc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonAck);
            this.Controls.Add(this.buttonOpen);
            this.Controls.Add(this.comboBoxPort);
            this.Name = "LoySerialPortUc";
            this.Size = new System.Drawing.Size(292, 37);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonOpen;
        private System.Windows.Forms.ComboBox comboBoxPort;
        private System.Windows.Forms.Button buttonAck;
        private System.Windows.Forms.Label label1;
    }
}
