﻿namespace SimDevice1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxCommRX = new System.Windows.Forms.TextBox();
            this.textBoxCouldTX = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 195);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 17);
            this.label2.TabIndex = 11;
            this.label2.Text = "Comm RX";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 17);
            this.label1.TabIndex = 10;
            this.label1.Text = "Could TX";
            // 
            // textBoxCommRX
            // 
            this.textBoxCommRX.Location = new System.Drawing.Point(21, 215);
            this.textBoxCommRX.Multiline = true;
            this.textBoxCommRX.Name = "textBoxCommRX";
            this.textBoxCommRX.Size = new System.Drawing.Size(670, 153);
            this.textBoxCommRX.TabIndex = 9;
            // 
            // textBoxCouldTX
            // 
            this.textBoxCouldTX.Location = new System.Drawing.Point(21, 29);
            this.textBoxCouldTX.Multiline = true;
            this.textBoxCouldTX.Name = "textBoxCouldTX";
            this.textBoxCouldTX.Size = new System.Drawing.Size(670, 153);
            this.textBoxCouldTX.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(716, 391);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxCommRX);
            this.Controls.Add(this.textBoxCouldTX);
            this.Name = "Form1";
            this.Text = "Sim Device 1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxCommRX;
        private System.Windows.Forms.TextBox textBoxCouldTX;
    }
}

