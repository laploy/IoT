﻿/// <remarks>
/// Laploy V.Angkul
/// laploy@gmail.com
/// July ,2017
/// </remarks>


//https://azure.microsoft.com/en-us/documentation/articles/iot-hub-csharp-csharp-c2d/
using System;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Azure.Devices;

namespace SendCloudToDevice
{
    public partial class Form1 : Form
    {
        ServiceClient serviceClient;
        string connectionString = "xxxxx";
        const string commandMessage = "Cloud to device message: ";

        public Form1()
        {
            InitializeComponent();
        }
        private async Task SendCloudToDeviceMessageAsync()
        {
            string message = "Cloud to device message: " + DateTime.Now;
            var commandMessage = new Microsoft.Azure.Devices.Message(Encoding.ASCII.GetBytes(message));
            await serviceClient.SendAsync("loyDev1", commandMessage);
            textBoxCouldTX.Invoke(new MethodInvoker(delegate { textBoxCouldTX.AppendText(message + "\r\n"); }));
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            serviceClient = ServiceClient.CreateFromConnectionString(connectionString);
            string msg = "Press SEND button to send a C2D message.";
            textBoxCouldTX.Invoke(new MethodInvoker(delegate { textBoxCouldTX.AppendText(msg + "\r\n"); }));
            
        }

        private void buttonSend_Click(object sender, EventArgs e)
        {
            SendCloudToDeviceMessageAsync().Wait(1);
        }
    }
}
