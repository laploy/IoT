﻿using System;
using System.Text;
using System.Windows.Forms;
using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;

namespace SimDevice2
{
    public partial class Form1 : Form
    {
        DeviceClient deviceClient;
        string myDevice = "loyDev1";
        string iotHubUri = "loyHub2.azure-devices.net";
        string deviceKey = "+cnQA4knixvot+Y86VCOuKdDfBrH9rdTu7+w6m0scdY=";

        public Form1()
        {
            InitializeComponent();
            deviceClient = DeviceClient.Create(iotHubUri, new DeviceAuthenticationWithRegistrySymmetricKey(myDevice, deviceKey));
        }
        private async void ReceiveC2dAsync()
        {
            string msg = "Receiving cloud to device messages from service";
            textBoxCouldTX.Invoke(new MethodInvoker(delegate { textBoxCouldTX.AppendText(msg + "\r\n"); }));
            while (true)
            {
                Microsoft.Azure.Devices.Client.Message receivedMessage = await deviceClient.ReceiveAsync();
                if (receivedMessage == null) continue;
                msg = Encoding.ASCII.GetString(receivedMessage.GetBytes());
                textBoxCouldTX.Invoke(new MethodInvoker(delegate { textBoxCouldTX.AppendText(msg + "\r\n"); }));
                await deviceClient.CompleteAsync(receivedMessage);
            }
        }
        private void buttonStart_Click(object sender, EventArgs e)
        {
            ReceiveC2dAsync();
        }
    }
}
