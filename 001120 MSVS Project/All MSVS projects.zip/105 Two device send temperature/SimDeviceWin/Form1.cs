﻿/// <remarks>
/// Laploy V.Angkul
/// laploy@gmail.com
/// July ,2017
/// </remarks>


using System;
using System.Text;
using System.Windows.Forms;
using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;

namespace SimDeviceWin
{
    public partial class Form1 : Form
    {
        DeviceClient deviceClient;
        string myDevice = "Alpha";
        string iotHubUri = "loyHub2.azure-devices.net";
        string deviceKey = "xxxxx";

        public Form1()
        {
            InitializeComponent();
            deviceClient = DeviceClient.Create(iotHubUri, new DeviceAuthenticationWithRegistrySymmetricKey(myDevice, deviceKey));
            loySerialPortUc1.OnDataReceived += LoySerialPortUc1_OnDataReceived;
        }

        private void LoySerialPortUc1_OnDataReceived(string recieveString)
        {
            textBoxCommRX.Invoke(new MethodInvoker(delegate { textBoxCommRX.AppendText(recieveString); }));
            SendDeviceToCloudMessagesAsync(recieveString);
        }

        private async void SendDeviceToCloudMessagesAsync(string data)
        {
            var telemetryDataPoint = new
            {
                deviceId = myDevice,
                temperature = Convert.ToDouble(data)
            };
            var messageString = JsonConvert.SerializeObject(telemetryDataPoint);
            var message = new Microsoft.Azure.Devices.Client.Message(Encoding.ASCII.GetBytes(messageString));
            await deviceClient.SendEventAsync(message);
            textBoxCouldTX.Invoke(new MethodInvoker(delegate { textBoxCouldTX.AppendText(DateTime.Now + messageString + "\r\n"); }));
        }
    }
}
