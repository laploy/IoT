﻿namespace SendCloudToDevice
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonLed1On = new System.Windows.Forms.Button();
            this.button1Off = new System.Windows.Forms.Button();
            this.buttonLed2Off = new System.Windows.Forms.Button();
            this.buttonLed2On = new System.Windows.Forms.Button();
            this.buttonLed3Off = new System.Windows.Forms.Button();
            this.buttonLed3On = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonLed1On
            // 
            this.buttonLed1On.Location = new System.Drawing.Point(228, 97);
            this.buttonLed1On.Name = "buttonLed1On";
            this.buttonLed1On.Size = new System.Drawing.Size(54, 28);
            this.buttonLed1On.TabIndex = 11;
            this.buttonLed1On.Text = "O N";
            this.buttonLed1On.UseVisualStyleBackColor = true;
            this.buttonLed1On.Click += new System.EventHandler(this.buttonLed1On_Click);
            // 
            // button1Off
            // 
            this.button1Off.Location = new System.Drawing.Point(304, 97);
            this.button1Off.Name = "button1Off";
            this.button1Off.Size = new System.Drawing.Size(54, 28);
            this.button1Off.TabIndex = 12;
            this.button1Off.Text = "O F F";
            this.button1Off.UseVisualStyleBackColor = true;
            this.button1Off.Click += new System.EventHandler(this.button1Off_Click);
            // 
            // buttonLed2Off
            // 
            this.buttonLed2Off.Location = new System.Drawing.Point(304, 146);
            this.buttonLed2Off.Name = "buttonLed2Off";
            this.buttonLed2Off.Size = new System.Drawing.Size(54, 28);
            this.buttonLed2Off.TabIndex = 14;
            this.buttonLed2Off.Text = "O F F";
            this.buttonLed2Off.UseVisualStyleBackColor = true;
            this.buttonLed2Off.Click += new System.EventHandler(this.buttonLed2Off_Click);
            // 
            // buttonLed2On
            // 
            this.buttonLed2On.Location = new System.Drawing.Point(228, 146);
            this.buttonLed2On.Name = "buttonLed2On";
            this.buttonLed2On.Size = new System.Drawing.Size(54, 28);
            this.buttonLed2On.TabIndex = 13;
            this.buttonLed2On.Text = "O N";
            this.buttonLed2On.UseVisualStyleBackColor = true;
            this.buttonLed2On.Click += new System.EventHandler(this.buttonLed2On_Click);
            // 
            // buttonLed3Off
            // 
            this.buttonLed3Off.Location = new System.Drawing.Point(304, 195);
            this.buttonLed3Off.Name = "buttonLed3Off";
            this.buttonLed3Off.Size = new System.Drawing.Size(54, 28);
            this.buttonLed3Off.TabIndex = 16;
            this.buttonLed3Off.Text = "O F F";
            this.buttonLed3Off.UseVisualStyleBackColor = true;
            this.buttonLed3Off.Click += new System.EventHandler(this.buttonLed3Off_Click);
            // 
            // buttonLed3On
            // 
            this.buttonLed3On.Location = new System.Drawing.Point(228, 195);
            this.buttonLed3On.Name = "buttonLed3On";
            this.buttonLed3On.Size = new System.Drawing.Size(54, 28);
            this.buttonLed3On.TabIndex = 15;
            this.buttonLed3On.Text = "O N";
            this.buttonLed3On.UseVisualStyleBackColor = true;
            this.buttonLed3On.Click += new System.EventHandler(this.buttonLed3On_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label1.Location = new System.Drawing.Point(129, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 24);
            this.label1.TabIndex = 17;
            this.label1.Text = "LED 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label2.Location = new System.Drawing.Point(129, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 24);
            this.label2.TabIndex = 18;
            this.label2.Text = "LED 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label3.Location = new System.Drawing.Point(129, 199);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 24);
            this.label3.TabIndex = 19;
            this.label3.Text = "LED 3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label4.Location = new System.Drawing.Point(31, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(436, 24);
            this.label4.TabIndex = 20;
            this.label4.Text = "SEND COMMAND FROM COULD TO DEVICE";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(505, 264);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonLed3Off);
            this.Controls.Add(this.buttonLed3On);
            this.Controls.Add(this.buttonLed2Off);
            this.Controls.Add(this.buttonLed2On);
            this.Controls.Add(this.button1Off);
            this.Controls.Add(this.buttonLed1On);
            this.Name = "Form1";
            this.Text = "SendCloudToDevice";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonLed1On;
        private System.Windows.Forms.Button button1Off;
        private System.Windows.Forms.Button buttonLed2Off;
        private System.Windows.Forms.Button buttonLed2On;
        private System.Windows.Forms.Button buttonLed3Off;
        private System.Windows.Forms.Button buttonLed3On;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
    }
}

