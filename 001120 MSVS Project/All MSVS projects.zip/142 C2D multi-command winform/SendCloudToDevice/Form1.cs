﻿//https://azure.microsoft.com/en-us/documentation/articles/iot-hub-csharp-csharp-c2d/
using System;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Azure.Devices;

namespace SendCloudToDevice
{
    public partial class Form1 : Form
    {
        ServiceClient serviceClient;
        string connectionString = "HostName=loyHub2.azure-devices.net;SharedAccessKeyName=iothubowner;SharedAccessKey=lOa5OkIQkGAhvVQRRB+6R/wWGG01dUPxJ3TC0vLAA9k=";
        const string commandMessage = "Cloud to device message: ";

        public Form1()
        {
            InitializeComponent();
        }
        private async Task SendCloudToDeviceMessageAsync(string message)
        {
            var commandMessage = new Microsoft.Azure.Devices.Message(Encoding.ASCII.GetBytes(message));
            await serviceClient.SendAsync("loyDev1", commandMessage);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            serviceClient = ServiceClient.CreateFromConnectionString(connectionString);
        }

        private void buttonLed1On_Click(object sender, EventArgs e)
        {
            SendCloudToDeviceMessageAsync("0,1").Wait(1);
        }
        private void button1Off_Click(object sender, EventArgs e)
        {
            SendCloudToDeviceMessageAsync("0,0").Wait(1);
        }
        private void buttonLed2On_Click(object sender, EventArgs e)
        {
            SendCloudToDeviceMessageAsync("1,1").Wait(1);
        }
        private void buttonLed2Off_Click(object sender, EventArgs e)
        {
            SendCloudToDeviceMessageAsync("1,0").Wait(1);
        }
        private void buttonLed3On_Click(object sender, EventArgs e)
        {
            SendCloudToDeviceMessageAsync("2,1").Wait(1);
        }
        private void buttonLed3Off_Click(object sender, EventArgs e)
        {
            SendCloudToDeviceMessageAsync("2,0").Wait(1);
        }
    }
}

//textBoxCouldTX.Invoke(new MethodInvoker(delegate { textBoxCouldTX.AppendText(msg + "\r\n"); }));