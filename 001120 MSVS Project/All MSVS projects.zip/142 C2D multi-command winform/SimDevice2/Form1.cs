﻿using System;
using System.Text;
using System.Windows.Forms;
using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;

namespace SimDevice2
{
    public partial class Form1 : Form
    {
        DeviceClient deviceClient;
        string myDevice = "loyDev1";
        string iotHubUri = "loyHub2.azure-devices.net";
        string deviceKey = "+cnQA4knixvot+Y86VCOuKdDfBrH9rdTu7+w6m0scdY=";

        public Form1()
        {
            InitializeComponent();
            deviceClient = DeviceClient.Create(iotHubUri, new DeviceAuthenticationWithRegistrySymmetricKey(myDevice, deviceKey));
        }
        private async void ReceiveC2dAsync()
        {
            while (true)
            {
                Microsoft.Azure.Devices.Client.Message receivedMessage = await deviceClient.ReceiveAsync();
                if (receivedMessage == null) continue;
                string msg = Encoding.ASCII.GetString(receivedMessage.GetBytes());
                Control(msg);
                await deviceClient.CompleteAsync(receivedMessage);
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            ReceiveC2dAsync();
        }
        private void Control(string msg)
        {
            string[] command = msg.Split(',');
            string ledId = command[0];
            string action = command[1];
            switch(ledId)
            {
                case "0":
                    if (action == "0") buttonLed1.Invoke(new MethodInvoker(delegate { buttonLed1.BackColor = System.Drawing.Color.Gainsboro; }));
                    if (action == "1") buttonLed1.Invoke(new MethodInvoker(delegate { buttonLed1.BackColor = System.Drawing.Color.OrangeRed; }));
                    break;
                case "1":
                    if (action == "0") buttonLed2.Invoke(new MethodInvoker(delegate { buttonLed2.BackColor = System.Drawing.Color.Gainsboro; }));
                    if (action == "1") buttonLed2.Invoke(new MethodInvoker(delegate { buttonLed2.BackColor = System.Drawing.Color.OrangeRed; }));
                    break;
                case "2":
                    if (action == "0") buttonLed3.Invoke(new MethodInvoker(delegate { buttonLed3.BackColor = System.Drawing.Color.Gainsboro; }));
                    if (action == "1") buttonLed3.Invoke(new MethodInvoker(delegate { buttonLed3.BackColor = System.Drawing.Color.OrangeRed; }));
                    break;
            }
        }
    }
}
//textBoxCouldTX.Invoke(new MethodInvoker(delegate { textBoxCouldTX.AppendText(msg + "\r\n"); }));