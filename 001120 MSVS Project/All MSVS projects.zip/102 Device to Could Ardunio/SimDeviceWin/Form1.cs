﻿/// <remarks>
/// Laploy V.Angkul
/// laploy@gmail.com
/// July ,2017
/// </remarks>

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;

namespace SimDeviceWin
{
    public partial class Form1 : Form
    {
        static DeviceClient deviceClient;
        static string iotHubUri = "xxxxx";
        static string deviceKey = "xxxx";

        public Form1()
        {
            InitializeComponent();
            deviceClient = DeviceClient.Create(iotHubUri, new DeviceAuthenticationWithRegistrySymmetricKey(deviceId, deviceKey));
            loySerialPortUc1.OnDataReceived += LoySerialPortUc1_OnDataReceived;
        }

        private void LoySerialPortUc1_OnDataReceived(string recieveString)
        {
            textBoxCommRX.Invoke(new MethodInvoker(delegate { textBoxCommRX.AppendText(recieveString); }));
            SendDeviceToCloudMessagesAsync(recieveString);
        }

        private async void SendDeviceToCloudMessagesAsync(string data)
        {
            var telemetryDataPoint = new
            {
                deviceId = deviceId,
                temperature = Convert.ToDouble(data)
        };
            var messageString = JsonConvert.SerializeObject(telemetryDataPoint);
            var message = new Microsoft.Azure.Devices.Client.Message(Encoding.ASCII.GetBytes(messageString));
            await deviceClient.SendEventAsync(message);
            textBoxCouldTX.Invoke(new MethodInvoker(delegate { textBoxCouldTX.AppendText(DateTime.Now + messageString + "\r\n"); }));
        }
    }
}
