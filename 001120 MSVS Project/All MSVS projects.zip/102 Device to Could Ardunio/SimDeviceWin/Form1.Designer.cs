﻿namespace SimDeviceWin
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.textBoxCouldTX = new System.Windows.Forms.TextBox();
            this.textBoxCommRX = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.loySerialPortUc1 = new LoySerialPortUserControl.LoySerialPortUc();
            this.SuspendLayout();
            // 
            // textBoxCouldTX
            // 
            this.textBoxCouldTX.Location = new System.Drawing.Point(12, 31);
            this.textBoxCouldTX.Multiline = true;
            this.textBoxCouldTX.Name = "textBoxCouldTX";
            this.textBoxCouldTX.Size = new System.Drawing.Size(670, 153);
            this.textBoxCouldTX.TabIndex = 0;
            // 
            // textBoxCommRX
            // 
            this.textBoxCommRX.Location = new System.Drawing.Point(12, 217);
            this.textBoxCommRX.Multiline = true;
            this.textBoxCommRX.Name = "textBoxCommRX";
            this.textBoxCommRX.Size = new System.Drawing.Size(670, 153);
            this.textBoxCommRX.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Could TX";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 197);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Comm RX";
            // 
            // loySerialPortUc1
            // 
            this.loySerialPortUc1.Location = new System.Drawing.Point(197, 411);
            this.loySerialPortUc1.Name = "loySerialPortUc1";
            this.loySerialPortUc1.RxMode = "text";
            this.loySerialPortUc1.Size = new System.Drawing.Size(292, 37);
            this.loySerialPortUc1.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(694, 485);
            this.Controls.Add(this.loySerialPortUc1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxCommRX);
            this.Controls.Add(this.textBoxCouldTX);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Device Simulator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxCouldTX;
        private System.Windows.Forms.TextBox textBoxCommRX;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private LoySerialPortUserControl.LoySerialPortUc loySerialPortUc1;
    }
}

