﻿/// <remarks>
/// Laploy V.Angkul
/// laploy@gmail.com
/// July ,2017
/// </remarks>


using System;
using System.Text;
using System.Windows.Forms;
using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;

namespace SimDevice2
{
    public partial class Form1 : Form
    {
        DeviceClient deviceClient;
        string myDevice = "loyDev1";
        string iotHubUri = "loyHub2.azure-devices.net";
        string deviceKey = "xxxxx";

        public Form1()
        {
            InitializeComponent();
            deviceClient = DeviceClient.Create(iotHubUri, new DeviceAuthenticationWithRegistrySymmetricKey(myDevice, deviceKey));
            Timer myTimer = new Timer();
            myTimer.Enabled = true;
            myTimer.Interval = 8000;
            myTimer.Tick += MyTimer_Tick;
        }

        private void MyTimer_Tick(object sender, EventArgs e)
        {
            double temper = 10; // m/s
            Random rand = new Random();
            double currentTemper = temper + rand.NextDouble() * 4 - 2;
            string temperStr = currentTemper.ToString();
            textBoxCommRX.Invoke(new MethodInvoker(delegate { textBoxCommRX.AppendText(temperStr + "\r\n") ; }));
            SendDeviceToCloudMessagesAsync(temperStr);
        }

        private async void SendDeviceToCloudMessagesAsync(string data)
        {
            var telemetryDataPoint = new
            {
                deviceId = myDevice,
                Temperature = Convert.ToDouble(data)
            };
            var messageString = JsonConvert.SerializeObject(telemetryDataPoint);
            var message = new Microsoft.Azure.Devices.Client.Message(Encoding.ASCII.GetBytes(messageString));
            await deviceClient.SendEventAsync(message);
            textBoxCouldTX.Invoke(new MethodInvoker(delegate { textBoxCouldTX.AppendText(DateTime.Now + messageString + "\r\n"); }));
        }
    }
}
