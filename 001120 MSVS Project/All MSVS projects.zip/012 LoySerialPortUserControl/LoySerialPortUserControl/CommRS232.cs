﻿/// <remarks>
/// modify base on R1.103e9
/// Laploy V.Angkul
/// April 3,2012
/// </remarks>

using System;
using System.IO.Ports;

namespace LoySerialPortUserControl
{
    public delegate void DataReceived(string recieveString);
    public delegate void DataReceivedDnp3(byte[] recieveDnp3);
    public delegate void DataReceivedText(string recieveText);
    public class CommRS232
    {
        public event DataReceived OnDataReceived;
        public event DataReceivedDnp3 OnDataReceivedDnp3;
        public event DataReceivedText OnDataReceivedText;
        public event EventHandler<CustomEventArgs> RaiseEvent232;
        private SerialPort myComPort;
        private bool dnp3Mode = false;
        public bool Dnp3Mode
        {
            get { return dnp3Mode; }
            set { dnp3Mode = value; }
        }
        private bool textMode = false;
        public bool TextMode
        {
            get { return textMode; }
            set { textMode = value; }
        }
        public bool RtsEnable
        {
            get { return myComPort.RtsEnable; }
            set { myComPort.RtsEnable = value; }
        }
        private string commPortName = "COM1";
        private string recieveString = "";
        private string recieveText = "";
        private byte[] recieveDnp3;
        private bool isOpen = false;
        public bool IsOpen
        {
            get
            {
                isOpen = myComPort.IsOpen;
                return isOpen;
            }
        }

        public CommRS232()
            : this("COM1")
        {
        }
        public CommRS232(string portName)
        {
            commPortName = portName;
            InitPort();
        }
        public void InitPort()
        {
            myComPort = new SerialPort();
            myComPort.BaudRate = 9600;
            myComPort.PortName = commPortName;
            myComPort.Parity = Parity.None;
            myComPort.DataBits = 8;
            myComPort.StopBits = StopBits.One;
            myComPort.ReadTimeout = 50000;
            myComPort.WriteTimeout = 50000;
            myComPort.ReadBufferSize = 1500;
            if (dnp3Mode)
            {
                myComPort.DataReceived += new SerialDataReceivedEventHandler(myComPort_DataReceivedDnp3);
                myComPort.DataReceived += (object sender, SerialDataReceivedEventArgs e) => { OnDataReceivedDnp3(recieveDnp3); };
            }
            else
            {
                if (!textMode)
                {
                    myComPort.DataReceived += new SerialDataReceivedEventHandler(myComPort_DataReceived);
                    myComPort.DataReceived += (object sender, SerialDataReceivedEventArgs e) => { OnDataReceived(recieveString); };
                }
                else
                {
                    myComPort.DataReceived += new SerialDataReceivedEventHandler(myComPort_DataReceivedText);
                    myComPort.DataReceived += (object sender, SerialDataReceivedEventArgs e) => { OnDataReceivedText(recieveText); };
                }
            }
        }

        void myComPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            recieveString = Read();
        }
        void myComPort_DataReceivedText(object sender, SerialDataReceivedEventArgs e)
        {
            recieveText = ReadText();
        }
        void myComPort_DataReceivedDnp3(object sender, SerialDataReceivedEventArgs e)
        {
            recieveDnp3 = ReadDnp3();
        }
        public bool Open()
        {
            try
            {
                myComPort.Open();
                OnRaiseEvent232(new CustomEventArgs(""), "OK Open : " + commPortName);
                return true;
            }
            catch
            {
                OnRaiseEvent232(new CustomEventArgs(""), "Error Open : " + commPortName);
                return false;
            }
        }
        public bool Close()
        {
            try
            {
                myComPort.Close();
                OnRaiseEvent232(new CustomEventArgs(""), "OK Close : " + commPortName);
                return true;
            }
            catch
            {
                OnRaiseEvent232(new CustomEventArgs(""), "Error Close : " + commPortName);
                return false;
            }
        }
        public string Read()
        {
            string message = "";
            try
            {
                message = myComPort.ReadExisting();
                OnRaiseEvent232(new CustomEventArgs(""), "OK Read String: " + commPortName);
            }
            catch { OnRaiseEvent232(new CustomEventArgs(""), "Error Read String: " + commPortName); }
            return message;
        }
        public string ReadText()
        {
            string message = "";
            try
            {
                message = myComPort.ReadLine();
                OnRaiseEvent232(new CustomEventArgs(""), "OK Read Text: " + commPortName);
            }
            catch { OnRaiseEvent232(new CustomEventArgs(""), "Error Read Text: " + commPortName); }
            return message;
        }
        public byte[] ReadDnp3()
        {
            int bytes = myComPort.BytesToRead;
            byte[] comBuffer = new byte[bytes];
            try
            {
                //Thread.Sleep(10);
                myComPort.Read(comBuffer, 0, bytes);
                //OnRaiseEvent232(new CustomEventArgs(""), "OK Read DNP3: " + commPortName);
            }
            catch { OnRaiseEvent232(new CustomEventArgs(""), "Error Read DNP3: " + commPortName); }
            return comBuffer;
        }
        public void Write(string s)
        {
            try
            {
                myComPort.Write(s);
                OnRaiseEvent232(new CustomEventArgs(""), "OK Write : " + commPortName);
            }
            catch { OnRaiseEvent232(new CustomEventArgs(""), "Error Write" + commPortName); }
        }
        public void Write(byte[] b)
        {
            try
            {
                myComPort.Write(b, 0, b.Length);
                OnRaiseEvent232(new CustomEventArgs(""), "OK Write : " + commPortName);
            }
            catch { OnRaiseEvent232(new CustomEventArgs(""), "Error Write " + commPortName); }
        }
        protected virtual void OnRaiseEvent232(CustomEventArgs e, string s)
        {
            EventHandler<CustomEventArgs> handler = RaiseEvent232;
            if (handler != null)
            {
                e.Message = s;
                handler(this, e);
            }
        }
    }
}