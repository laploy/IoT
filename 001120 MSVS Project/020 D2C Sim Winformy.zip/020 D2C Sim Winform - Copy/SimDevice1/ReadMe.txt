﻿D2C sim Winform

Microsof Azure IoT course loploy 2017

This program show you how to Send a message (temperature  data sim) to Azure IoT Hub by mouse click at a button.

You may use Windows Device Explorer as a back-end app to monitor the data when testing this app.