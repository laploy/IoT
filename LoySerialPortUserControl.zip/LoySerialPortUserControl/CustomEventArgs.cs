﻿/// <remarks>
/// modify base on R1.103e9
/// Laploy V.Angkul
/// April 3,2012
/// </remarks>

using System;

namespace LoySerialPortUserControl
{
    public class CustomEventArgs : EventArgs
    {
        public CustomEventArgs(string s)
        {
            message = s;
        }
        private string message;

        public string Message
        {
            get { return message; }
            set { message = value; }
        }
    }
}